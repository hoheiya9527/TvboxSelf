import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public class LiveTest {

    public static String url = "http://tonkiang.us/?s=";//解析源
    private static CountDownLatch countDownLatch;

    public static void main1(String[] args) {
//        ArrayList<LiveItem> parse = parse("CCTV-5+", url);
        LinkedHashMap<String, List<LiveItem>> lives = new LinkedHashMap<>();
        List<LiveItem> items = new ArrayList<>();
        items.add(new LiveItem("test1", "https_test"));
        items.add(new LiveItem("test2", "https_test2"));
        lives.put("央视", items);
        lives.put("卫视", items);
        writeFile(
                new SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(new Date())
                        + ".txt",
                lives);
    }


    public static void main(String[] args) {
        ///////////////////
//        boolean test = true;
//        if (test) {
////            main1(null);
////            return;
//            args = new String[1];
//            args[0] = "D://LiveChannel.txt";
//        }
        ///////////////////

        if (args == null || args.length == 0) {
            System.out.println("传参 频道 不可为空");
            return;
        }
        String filePath = args[0];
//        String filePath = "D://LiveName.txt";

        HashMap<String, List<String>> liveNames = getLiveName(filePath);
        if (liveNames.size() == 0) {
            System.out.println("==待获取频道为空");
            return;
        }
        long startTime = System.currentTimeMillis();
        ExecutorService threadPool = Executors.newCachedThreadPool();
        countDownLatch = new CountDownLatch(liveNames.size());
        LinkedHashMap<String, List<LiveItem>> liveMap = new LinkedHashMap<>();//所有组+所有频道
        for (Map.Entry<String, List<String>> entry : liveNames.entrySet()) {
            //
            threadPool.execute(() -> {
                parseByThread(liveMap, entry);
            });
        }
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("============解析完成==耗时(秒)：" + (System.currentTimeMillis() - startTime) / 1000);
        //
        //
        String fileName = "live_by_parser_" +
                new SimpleDateFormat("yyMMdd_hhmmss", Locale.CHINA).format(new Date()) + ".txt";
        //
        writeFile(fileName, liveMap);
        //
        threadPool.shutdown();
        System.exit(0);
    }

    private static void parseByThread(LinkedHashMap<String, List<LiveItem>> liveMap,
                                      Map.Entry<String, List<String>> entry) {
        //
        ArrayList<LiveItem> items = new ArrayList<>();//单组所有频道
        System.out.println("==分组:" + entry.getKey());
        System.out.println("==Thread==" + Thread.currentThread().getName());
        List<String> values = entry.getValue();
        for (String name : values) {
//                System.out.println(name);
            name = name.trim();
            ArrayList<LiveItem> liveItems = parse(name, url);
            if (liveItems.size() == 0) {
                System.out.println("==获取频道失败：" + name);
                continue;
            }
            items.addAll(liveItems);
        }
        //
        liveMap.put(entry.getKey(), items);
        countDownLatch.countDown();
    }

    private static void writeFile(String fileName, LinkedHashMap<String, List<LiveItem>> liveMap) {
        FileOutputStream outputStream = null;
        OutputStreamWriter outputStreamWriter = null;
        BufferedWriter bufferedWriter = null;
        try {
            outputStream = new FileOutputStream(fileName);
            outputStreamWriter = new OutputStreamWriter(outputStream);
            bufferedWriter = new BufferedWriter(outputStreamWriter);
            //
            for (Map.Entry<String, List<LiveItem>> entry : liveMap.entrySet()) {
//                System.out.println("=======分组：" + entry.getKey());
                bufferedWriter.write(entry.getKey());
                bufferedWriter.write(",#genre#");
                bufferedWriter.newLine();
                //
                List<LiveItem> lives = entry.getValue();
                for (LiveItem it : lives) {
//                    System.out.println(it.getName() + " >> " + it.getLink());
                    bufferedWriter.write(it.getName());
                    bufferedWriter.write(",");
                    bufferedWriter.write(it.getLink());
                    bufferedWriter.newLine();
                }
                bufferedWriter.newLine();
            }
            bufferedWriter.flush();
            System.out.println("文件输出完成：" + fileName);
            //
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bufferedWriter != null)
                    bufferedWriter.close();
                if (outputStreamWriter != null)
                    outputStreamWriter.close();
                if (outputStream != null)
                    outputStream.close();
            } catch (Exception ignored) {
            }
        }

    }

    private static LinkedHashMap<String, List<String>> getLiveName(String filePath) {
        LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
        if (filePath == null) {
            System.out.println("filePath is null");
            return map;
        }
        System.out.println("===filePath:" + filePath);
        FileInputStream fileInputStream = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;
        try {
            fileInputStream = new FileInputStream(filePath);
            inputStreamReader = new InputStreamReader(fileInputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            ArrayList<String> strings = null;
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (line.startsWith("#")) {//分组
                    strings = new ArrayList<>();
                    map.put(line.substring(1), strings);
                    continue;
                }
                if (strings != null && !line.trim().equals("")) {
                    strings.add(line);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bufferedReader != null)
                    bufferedReader.close();
                if (inputStreamReader != null)
                    inputStreamReader.close();
                if (fileInputStream != null)
                    fileInputStream.close();
            } catch (Exception ignored) {
            }
        }
        return map;
    }

    /**
     * 解析获取
     *
     * @param keyword
     * @param url
     */
    private static ArrayList<LiveItem> parse(String keyword, String url) {
        int max = 3;//只获取最大3个链接
        ArrayList<LiveItem> liveItems = new ArrayList<>();
        try {
            Document document = Jsoup.connect(url + URLEncoder.encode(keyword, "UTF-8")).get();
//            System.out.println(document);
            Elements elements = document.select("div.result");
            if (elements.size() == 0) {
                System.out.println("===========获取不到节点=========\n" + document);
                return liveItems;
            }
            int index = 0;
            for (Element element : elements) {
                //
                if (index >= max) {
                    return liveItems;
                }
//                System.out.println("------------------");
//                System.out.println(element);
                Elements tags = element.select("div.channel div");
                Elements values = element.select("div.m3u8 table td:nth-child(2)");

                if (tags.size() > 0 && values.size() > 0) {
                    String name = tags.get(0).text();
                    String link = values.get(0).text();
//                    System.out.println(name + "|" + keyword + " >> " + name.equalsIgnoreCase(keyword));
                    if (name.equalsIgnoreCase(keyword)) {
//                        System.out.println(keyword);
//                        System.out.println(link);

                        boolean isIn = false;
                        //验证该链接是否已添加
                        for (LiveItem item : liveItems) {
                            if (item.getLink().equals(link)) {
                                isIn = true;
                                break;
                            }
                        }
                        if (isIn) {
                            continue;
                        }
                        //验证链接可用性
                        String connectUrl = getConnectUrl(name, link);
                        if (connectUrl != null) {
                            liveItems.add(new LiveItem(keyword, connectUrl));
                            index++;
                        }
                        //
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return liveItems;
    }

    public static String getConnectUrl(String name, String urlStr) {
        int counts = 0;
        if (urlStr == null) {
            return null;
        }
        URL url;
        System.out.println("==check [" + name + "]== link :" + urlStr);
        while (counts < 3) {
            try {
                url = new URL(urlStr);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setConnectTimeout(3 * 1000);
                con.setReadTimeout(3 * 1000);
                int state = con.getResponseCode();
                System.out.println(counts + "= " + state);
                if (state == HttpURLConnection.HTTP_OK) {
                    return urlStr;
                } else if (state == HttpURLConnection.HTTP_MOVED_TEMP
                        || state == HttpURLConnection.HTTP_MOVED_PERM) {
                    String location = con.getHeaderField("Location");
                    System.out.println("==Redirect link :" + location);
                    con.disconnect();
                    urlStr = location;
                    counts--;
                }
            } catch (Exception ignored) {
            }
            counts++;
        }
        return null;
    }

    static class LiveItem {
        private String name;
        private String link;

        public LiveItem(String name, String link) {
            this.name = name;
            this.link = link;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getLink() {
            return link;
        }

        public void setLink(String link) {
            this.link = link;
        }

        @Override
        public String toString() {
            return "LiveItem{" + "name='" + name + '\'' + ", link='" + link + '\'' + '}';
        }
    }
}
